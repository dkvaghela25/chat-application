import Header from './Header';
import Footer from './Footer';
import NothingHere from './NothingHere';
import { useSocketContext } from '../../contexts/socketContext';
import { useEffect, useState } from 'react';
import ActiveChatDetails from './ActiveChatDetails';
import Messages from './Messages';

const ActiveChat = () => {

    const { roomId } = useSocketContext();
    const [activeChatDetailsIsOpen, setActiveChatDetailsIsOpen] = useState(false);
    const [highlightedMessageId, setHighlightedMessageId] = useState(null);
    const [displayChat, setDisplayChat] = useState(true);

    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setActiveChatDetailsIsOpen(false);
        setDisplayChat(true);
        setHighlightedMessageId(null);
    }, [roomId]);

    return (
        <>
            {!roomId
                ? <NothingHere />
                : activeChatDetailsIsOpen
                    ? <ActiveChatDetails setActiveChatDetailsIsOpen={setActiveChatDetailsIsOpen} />
                    : (
                        <div className="flex flex-col w-full h-full mx-auto bg-white/80 backdrop-blur-md border border-slate-200 overflow-hidden shadow-xl">
                            <Header
                                setActiveChatDetailsIsOpen={setActiveChatDetailsIsOpen}
                                setHighlightedMessageId={setHighlightedMessageId}
                                displayChat={displayChat}
                                setDisplayChat={setDisplayChat}
                            />
                            <Messages highlightedMessageId={highlightedMessageId} displayChat={displayChat} />
                            {displayChat && <Footer />}
                        </div>
                    )
            }
        </>
    );
};

export default ActiveChat;